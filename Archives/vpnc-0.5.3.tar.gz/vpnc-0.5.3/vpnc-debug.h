/* Automatically generated with enum2debug.pl: Don't edit! */

struct debug_strings {
	unsigned int id;
	const char *string;
};

extern const char *val_to_string(unsigned int, const struct debug_strings *);

extern const struct debug_strings isakmp_payload_enum_array[];
extern const struct debug_strings isakmp_exchange_enum_array[];
extern const struct debug_strings isakmp_doi_enum_array[];
extern const struct debug_strings isakmp_notify_enum_array[];
extern const struct debug_strings dwr_ike_delete_array[];
extern const struct debug_strings isakmp_certificate_enum_array[];
extern const struct debug_strings ike_attr_enum_array[];
extern const struct debug_strings ike_enc_enum_array[];
extern const struct debug_strings ike_hash_enum_array[];
extern const struct debug_strings ike_auth_enum_array[];
extern const struct debug_strings ike_group_enum_array[];
extern const struct debug_strings ike_group_type_enum_array[];
extern const struct debug_strings ike_life_enum_array[];
extern const struct debug_strings isakmp_ipsec_sit_enum_array[];
extern const struct debug_strings isakmp_ipsec_id_enum_array[];
extern const struct debug_strings isakmp_ipsec_proto_enum_array[];
extern const struct debug_strings isakmp_ipsec_key_enum_array[];
extern const struct debug_strings isakmp_ipsec_ah_enum_array[];
extern const struct debug_strings isakmp_ipsec_esp_enum_array[];
extern const struct debug_strings isakmp_ipsec_attr_enum_array[];
extern const struct debug_strings isakmp_ipsec_ipcomp_enum_array[];
extern const struct debug_strings ipsec_life_enum_array[];
extern const struct debug_strings ipsec_encap_enum_array[];
extern const struct debug_strings ipsec_auth_enum_array[];
extern const struct debug_strings isakmp_modecfg_cfg_enum_array[];
extern const struct debug_strings isakmp_modecfg_attrib_enum_array[];
